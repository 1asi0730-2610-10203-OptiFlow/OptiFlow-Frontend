import { Role } from '../domain/model/role.entity.js';

const ROLE_MAP = {
    'ADMIN': {
        displayName: 'Administrador',
        description: 'Acceso total al sistema',
        color: '#ef4444'
    },
    'OPTOMETRIST': {
        displayName: 'Optometrista',
        description: 'Historias clínicas, recetas, datos clínicos',
        color: '#8b5cf6'
    },
    'SALES_ADVISOR': {
        displayName: 'Óptico / Asesor de Ventas',
        description: 'Ventas, inventario, registros de pacientes',
        color: '#3b82f6'
    },
    'RECEPTIONIST': {
        displayName: 'Recepcionista',
        description: 'Citas, registros de pacientes (solo lectura)',
        color: '#10b981'
    }
};

export class RoleAssembler {
    static toEntity(data, userCount = 0) {
        // Prioritize data from DB, fallback to map
        const metadata = ROLE_MAP[data.name] || {
            displayName: data.displayName || data.name,
            description: data.description || 'Rol del sistema',
            color: data.color || '#64748b'
        };

        return new Role(
            data.role_id || data.id,
            data.displayName || metadata.displayName,
            data.description || metadata.description,
            userCount,
            data.color || metadata.color
        );
    }

    static toEntities(roles, employees = []) {
        return roles.map(role => {
            const roleId = role.role_id || role.id;
            const count = employees.filter(emp => emp.role_id === roleId).length;
            return this.toEntity(role, count);
        });
    }
}
